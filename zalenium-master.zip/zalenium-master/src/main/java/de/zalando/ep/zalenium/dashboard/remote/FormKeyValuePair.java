package de.zalando.ep.zalenium.dashboard.remote;

import org.apache.http.entity.ContentType;

public class FormKeyValuePair extends FormField {
    public String value;
    public ContentType mimeType;
}
